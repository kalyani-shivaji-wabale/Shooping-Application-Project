package Daointerface;

import java.util.List;

import com.kiranacademy.entity.Mobile;

public interface sortinpriceinterface {
	public List<Mobile> getAllMobile();

}