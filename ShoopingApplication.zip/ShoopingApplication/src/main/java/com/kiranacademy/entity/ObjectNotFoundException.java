package com.kiranacademy.entity;

public class ObjectNotFoundException extends RuntimeException{
	public ObjectNotFoundException(String message) {
		super(message);
	}

}
