package com.kiranacademy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile {
	@Id
	public Integer mobileid;
public 	Integer price;
	public Integer speed;
	//Integer is class and price is reference using which we can call the compareTo() method.
	//using primitive int it is not possible
	public Integer getMobileid() {
		return mobileid;
	}
	public void setMobileid(Integer mobileid) {
		this.mobileid = mobileid;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", price=" + price + ", speed=" + speed + "]";
	}
	

}
