package com.kiranacademy.da0;

import java.util.Comparator;

import com.kiranacademy.entity.Mobile;
/* sort mobile object based on ascending order of price and if price are equal then sort mobie based on descending order on speed of mobilr*/
public class SortOnPrice implements Comparator<Mobile> {
	public int compare(Mobile mobile1,Mobile mobile2) {
		Integer price1=mobile1.price;
		Integer price2=mobile2.price;
		//if price are equal then sort based on desennding order of speed
		if(price1.equals(price2)) 
			// - indicate desending order
	return -mobile1.speed.compareTo(mobile2.speed);
		else
			return price1.compareTo(price2);
		}
	}
	
	


