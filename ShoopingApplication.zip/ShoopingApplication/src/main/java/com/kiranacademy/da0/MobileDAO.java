package com.kiranacademy.da0;

import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kiranacademy.entity.Mobile;

import Daointerface.sortinpriceinterface;

@Repository
public class MobileDAO implements sortinpriceinterface{
	@Autowired
	SessionFactory factory;
//	public List<Mobile> getAllMobile(){
//		 Session session=factory.openSession();
//Criteria criteria=session.createCriteria(Mobile.class);
//List<Mobile> list=criteria.list();
//Collections.sort(list,new SortOnPrice());
//		 
//		return list;
//		
//	}

	@Override
	public List<Mobile> getAllMobile() {
		// TODO Auto-generated method stub
		return null;
	}

}
