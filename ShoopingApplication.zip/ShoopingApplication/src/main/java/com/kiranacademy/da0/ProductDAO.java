package com.kiranacademy.da0;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kiranacademy.entity.Category;
import com.kiranacademy.entity.Product;
import com.kiranacademy.entity.ProductInfo;

import java.util.ArrayList;
@Repository
public class ProductDAO {
	@Autowired
	SessionFactory factory;
	public Product addProduct(Product product,@PathVariable int cid)
	{
		System.out.println("Category id is " + cid);
		
		Session session=factory.openSession();
		
		Category category=session.load(Category.class,cid);
		
		System.out.println("Products from given catergory are :- " + category.getProducts());
		
		/* get list of product and add product into it  */
		
		List<Product> productlist=category.getProducts();
					
		Transaction transaction=session.beginTransaction();
		
			productlist.add(product);
						
		transaction.commit();
				
		System.out.println("product added into database");
		
		return product;
		
	
	}
	public Product updateProduct(Product clientProduct)
	{
				Session session=factory.openSession();
				 Product productfromdb=session.load(Product.class,clientProduct.getPid());
				 productfromdb.setName(clientProduct.getName());
				 productfromdb.setPrice(clientProduct.getPrice());
				 productfromdb.setPid(clientProduct.getPid());
				Transaction transaction=session.beginTransaction();
				
					session.update(clientProduct);
								
				transaction.commit();
								
return clientProduct;
	}
//}
//	public List<Product> getall() {
//		
//			Session session=factory.openSession();
//			Criteria criteria=session.createCriteria(Product.class);
//			List<Product> list=criteria.list();
//			return list;
//			
//		}
//	
//	
//	public List<ProductInfo>   allproductwithcategory()
//	{
//		
//		Session session=factory.openSession();
//Query query=session.createSQLQuery("select p1.pid,p1.name as pname,p1.price,c1.cid,c1.name as cname from product as p1 join category as c1 ON p1.cid=c1.cid");
//		List<Object[]> list=query.list();
//		//in order to dispaly data in from of json string
//		ArrayList<ProductInfo> arraylist=new ArrayList<ProductInfo>();
//		for (Object[] array: list) {
//			arraylist.add(new ProductInfo((int)array[0],(String)array[1],(int)array[2],(int)array[3],(String)array[4]));
//		}
//		return arraylist;
//	
//	}
//	
//	public List<ProductInfo>   singleproductwithcategory(int pid)
//	{
//		
//		Session session=factory.openSession();
//Query query=session.createSQLQuery("select p1.pid,p1.name as pname,p1.price,c1.cid,c1.name as cname from product as p1 join category as c1 ON p1.cid=c1.cid and pid="+pid);
//		List<Object[]> list=query.list();
//		//in order to dispaly data in from of json string
//		ArrayList<ProductInfo> arraylist=new ArrayList<ProductInfo>();
//		for (Object[] array: list) {
//			arraylist.add(new ProductInfo((int)array[0],(String)array[1],(int)array[2],(int)array[3],(String)array[4]));
//		}
//		return arraylist;
//	
//	}
//	public Product deleteProduct(int pid)
//	{
//		Session session=factory.openSession();
//		Product product=session.get(Product.class,pid);
//		
//		Transaction tx=session.beginTransaction();
//				session.delete(product);
//		tx.commit();
//		
//		return product;
//	}
//	public Product saveproduct(Product product) {
//		
//Session session=factory.openSession();
//		
//		Transaction tx=session.beginTransaction();
//		
//				session.save(product);
//				
//		tx.commit();
//		
//		return product;
//	}
	public Product deleteProduct(Product product) {
		// TODO Auto-generated method stub
		
		Session session=factory.openSession();
Criteria criteria=session.createCriteria(Product.class);
List<Product> products=criteria.list();
		Transaction tx=session.beginTransaction();
		
tx.commit();

return product;
	}

	
	public List<Product> allProducts()
	{
		Session session=factory.openSession();
		Criteria criteria=session.createCriteria(Product.class);
		List<Product> list=criteria.list();
		return list;
		// [pid=1 name=pen price=100] Product class object
		// Spring calls getter methods to read data of variables and then create JSON String
	}
	public Product viewproduct(int pid)
	{
		Session session=factory.openSession();
		
		Product product=session.get(Product.class,pid);
		
		return product;
	
	}
	}

