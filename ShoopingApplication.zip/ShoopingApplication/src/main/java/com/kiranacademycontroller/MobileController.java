package com.kiranacademycontroller;

import java.util.List;
import java.util.TreeSet;
import java.util.ArrayList;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kiranacademy.da0.SortOnPrice;
import com.kiranacademy.entity.Mobile;
//39 ,inuter after 19
@RestController
public class MobileController {
	@Autowired
	SessionFactory factory;
	@RequestMapping("getData")
	public List<Mobile> getData(){
		List<Mobile> arrayList=factory.openSession().createCriteria(Mobile.class).list();
		//List<Mobile> arrayList=factory.openSession().createCriteria(Mobile.class).add(Restrictions.between("price",15,30)).list();
		System.out.println(arrayList);
		//constructor of tresset clas require comparator object, heance we have passes object ofimplrmentato=ion class of compartor interface
		//Treeset will sort mobile objects based on given definitionof compare method
		//treeset will sort object on price basis by using object of SortOnPrice()
		TreeSet<Mobile> treeset=new TreeSet(new SortOnPrice());
		treeset.addAll(arrayList);
		
		for(Mobile mobile:arrayList) {
			int price=mobile.price;
			if(price>=15 && price<=30)
				treeset.add(mobile);
		}
		//treeset.addAll(arrayList); using between method
		ArrayList<Mobile> mobiles=new ArrayList(treeset);
		return mobiles;
	}
//		@GetMapping("getdata2")
//		public TreeSet<Mobile> getdata2(){
//			Session session=factory.openSession();
//			Criteria criteria=session.createCriteria(Mobile.class);
//			criteria.add(Restrictions.between("price",15,30));
//			List<Mobile> list=criteria.list();
//			
//			SortOnPrice sortonprice=new SortOnPrice();
//			TreeSet<Mobile> treeset=new TreeSet(sortonprice);
//			treeset.addAll(list);
//			return treeset;
//		}
//		
		
	}

	

