package com.kiranacdemy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiranacademy.da0.MobileDAO;
import com.kiranacademy.entity.Mobile;

@Service
public class MobileService {
	@Autowired
	MobileDAO dao;
	public List<Mobile> getAllMobile(){
	return	dao.getAllMobile();
	
	}

}
