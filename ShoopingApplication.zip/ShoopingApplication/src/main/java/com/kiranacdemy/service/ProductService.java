package com.kiranacdemy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.kiranacademy.da0.ProductDAO;
import com.kiranacademy.entity.Product;
import com.kiranacademy.entity.ProductInfo;

@Service
public class ProductService {

	@Autowired
	 ProductDAO dao;
	public Product addProduct(Product product,@PathVariable int cid)
	{
		return dao.addProduct(product, cid);
	}
//	
	public Product updateProduct(Product clientProduct)
	{
		return dao.updateProduct(clientProduct);
}
//	
//	public List<Product> getall()
//	{
//		return dao.getall();
//	}
//	
//	public List<ProductInfo>   allproductwithcategory()
//	 {
//		return dao.allproductwithcategory();
//}
//	public List<ProductInfo>   singleproductwithcategory(int pid)
//	{
//		return dao.singleproductwithcategory(pid);
//}
//
//	public Product deleteProduct(int pid)
//	{
//		return dao.deleteProduct(pid);
//	}
//
//	public Product saveproduct(Product product) {
//		// TODO Auto-generated method stub
//		return dao.saveproduct(product);
//	}
//
//	
	public Product deleteProduct(Product product) {
	// TODO Auto-generated method stub
		return dao.deleteProduct(product);
	}
	public List<Product> allProducts()
	{
		return dao.allProducts();
	}
	public Product viewproduct(int pid) {
		// TODO Auto-generated method stub
		return dao.viewproduct(pid);
	}
	}

